﻿namespace Mission.Entities.Models.CommonModels
{
    public class UploadFileRequestModel
    {
        public string ModuleName { get; set; }
    }
}
